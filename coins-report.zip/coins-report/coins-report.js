const message = document.querySelector('.message');
const requestUrl2 = 'https://jsonplaceholder.typicode.com/users';

const requestUrl = 'https://whattomine.com/coins/113.json?'

function sendRequest(method, url, body = null) {
  const param = {
    method: method,
    body: JSON.stringify(body),
    headers: {
      'Content-Type': 'application/json',
      'Access-Control-Allow-Origin': '*',
      Origin: 'https://javascript.info'
    }
  }

  if (method !== 'POST') {
    param.body = null;
  }
  // console.log(param);

  return fetch(url, param).then(responce => {
    if (responce.ok) {
      return responce.json()
    }
    return responce.json().then(error => {
      const er = new Error(`Ошибка ${error}`);
      er.data = error;
      throw er;
    })
  })
}



const bodyToSend = {
  name: 'Jack',
  age: 20,
  city: 'NY',
  gender: 'male'
};


function clearClick() {
  message.style.display = 'none';
  message.innerHTML = null;
}



function fetchGetClick() {
  if (message.style.display !== 'none') {
    clearClick();
  }
  message.style.display = 'block';
  let messageHeader = `<h3>Запрос Fetch по адресу <br> <a href="${requestUrl}">${requestUrl}</a></h3>`;
  message.innerHTML = messageHeader;
  let messageSubHeader = document.createElement('h4');
  let messageString = document.createElement('p');

  messageSubHeader.innerText = 'Запрос типа GET';
  message.append(messageSubHeader);

  sendRequest('GET', requestUrl)
    .then(data => {
      console.log(data);
      data.forEach(el => {
        console.log(el);
        messageString.innerHTML += `<p>${JSON.stringify(el)}</p>`;
      });
      message.append(messageString);
    })
    .catch(err => {
      console.log(err);
      messageString.innerText = JSON.stringify(err);
      message.append(messageString);
    });
}